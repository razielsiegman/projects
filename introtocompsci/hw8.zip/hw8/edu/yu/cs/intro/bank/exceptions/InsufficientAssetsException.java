package edu.yu.cs.intro.bank.exceptions;

public class InsufficientAssetsException extends Exception {
}
