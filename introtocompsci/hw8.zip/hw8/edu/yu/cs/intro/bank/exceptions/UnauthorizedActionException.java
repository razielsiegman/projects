package edu.yu.cs.intro.bank.exceptions;

public class UnauthorizedActionException extends Exception {
}
