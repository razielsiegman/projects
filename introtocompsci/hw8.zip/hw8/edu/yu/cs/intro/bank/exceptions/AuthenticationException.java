package edu.yu.cs.intro.bank.exceptions;

public class AuthenticationException extends Exception {
}
